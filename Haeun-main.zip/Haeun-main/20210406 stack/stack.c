#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>

#define Max_size 100

typedef struct people{
	int age;
}P;

P stack1[Max_size];
//P* stack2;

int top = -1;

void push(int a);
void stackFull();
int pop();
void stackEmpty();

int main()
{
	//stack2 = malloc(sizeof(*stack2));

	for (int i = 0; i < 10; i++)
	{
		push(i + 10);
	}
	
	for (int i = 0; i < 12; i++)
	{
		printf("%d  ", pop());
	}
}

void push(int a)
{
	if (top >= Max_size)
	{
		stackFull();
	}
	stack1[++top].age = a;
}
void stackFull()
{
	printf("stack Full\n");
	exit(EXIT_FAILURE);
}

int pop()
{
	if (top <= -1)
	{
		stackEmpty();
	}
	return stack1[top--].age;
}
void stackEmpty()
{
	printf("stack Empty\n");
	exit(EXIT_FAILURE);
}