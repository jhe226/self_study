#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>

typedef struct people {
	int age;
	int age2;
}P;

P* stack2;

int top = -1;
int capacity = 1;

void push(P a);
void stackFull();
P pop();
void stackEmpty();
void stack_print();

int main()
{
	stack2 = malloc(sizeof(*stack2));

	P a;

	for (int i = 1; i < 10; i++)
	{
		a.age = i + 10;
		a.age2 = i + 20;
		push(a);
	}

	for (int i = 1; i < 10; i++)
	{
		stack_print();
	}

	free(stack2);
	return 0;
}
void stack_print()
{
	printf("%4d %4d\n", pop().age, pop().age2);
}

void push(P a)
{
	if (top >= capacity - 1)
	{
		stackFull();
	}
	stack2[++top] = a;
}
void stackFull()
{
	stack2 = realloc(stack2, sizeof(*stack2) * capacity * 2);
	capacity *= 2;
}

P pop()
{
	if (top <= -1)
	{
		stackEmpty();
	}
	return stack2[top--];
}
void stackEmpty()
{
	printf("stack Empty\n");
	exit(EXIT_FAILURE);
}