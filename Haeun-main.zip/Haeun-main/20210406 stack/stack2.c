#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>

typedef struct people {
	int age;
}P;

P* stack2;

int top = -1;
int capacity = 1;

void push(int a);
void stackFull();
int pop();
void stackEmpty();
void stack_print();

int main()
{
	stack2 = malloc(sizeof(*stack2));

	for (int i = 1; i < 101; i++)
	{
		push(i + 10);
	}

	for (int i = 1; i < 101; i++)
	{
		stack_print();
		if (i % 10 == 0)
			printf("\n");
	}

	free(stack2);
	return 0;
}
void stack_print()
{
	printf("%4d", pop());
}

void push(int a)
{
	if (top >= capacity-1)
	{
		stackFull();
	}
	stack2[++top].age = a;
}
void stackFull()
{
	stack2 = realloc(stack2, sizeof(*stack2) * capacity * 2);
	capacity *= 2;
}

int pop()
{
	if (top <= -1)
	{
		stackEmpty();
	}
	return stack2[top--].age;
}
void stackEmpty()
{
	printf("stack Empty\n");
	exit(EXIT_FAILURE);
}